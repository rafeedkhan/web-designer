﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Web.Security;
using System.Data;
using System.IO;
public partial class Adddoctoradmin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Admin"] == null)
            Response.Redirect("AdminLogin.aspx");

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        if (imageupload.HasFile)
        {
            HttpPostedFile postedFile = imageupload.PostedFile;
            string filename = Path.GetFileName(postedFile.FileName);
            string fileExtension = Path.GetExtension(filename);
            int fileSize = postedFile.ContentLength;
            string doctorName = TextBox1.Text.ToString();
            string Qualification = TextBox2.Text.ToString();
            string Department = TextBox3.Text.ToString();
            string Specialisation = TextBox4.Text.ToString();
            string Contact = TextBox5.Text.ToString();


            if (doctorName != null && Qualification != null && Department != null && Specialisation != null && Contact != null && (fileExtension.ToLower() == ".jpg" || fileExtension.ToLower() == ".gif"
                || fileExtension.ToLower() == ".png" || fileExtension.ToLower() == ".bmp"))
            {
                Stream stream = postedFile.InputStream;
                BinaryReader binaryReader = new BinaryReader(stream);
                Byte[] bytes = binaryReader.ReadBytes((int)stream.Length);


                SqlConnection con = new SqlConnection();
                con.ConnectionString = ConfigurationManager.ConnectionStrings["messi"].ConnectionString;

                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO doctorinfo (Doctorsname,Qualification,Department,Specialization,Contact,ImageData) VALUES (@name,@Qualific,@Dept,@specia,@Conta,@pic)", con);
                    //cmd.CommandType = CommandType.StoredProcedure;
                    // (@Id,@name,@Qualific,@Dept,@specia,@Conta,@pic)
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;

                    
                    cmd.Parameters.AddWithValue("@name", doctorName);
                    cmd.Parameters.AddWithValue("@Qualific", Qualification);
                    cmd.Parameters.AddWithValue("@Dept", Department);
                    cmd.Parameters.AddWithValue("@specia", Specialisation);
                    cmd.Parameters.AddWithValue("@Conta", Contact);
                    cmd.Parameters.AddWithValue("@pic", bytes);


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    TextBox1.Text = null;
                    TextBox2.Text = null;
                    TextBox3.Text = null;
                    TextBox4.Text = null;
                    TextBox5.Text = null;

                    Response.Redirect("AdminPage.aspx");
                    

                }
            }


        }
        else
        {
            Label6.Text = "You must fill every box and must choose a jpg file.";

        }
    }
}